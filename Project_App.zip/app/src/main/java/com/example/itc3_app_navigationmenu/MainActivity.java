package com.example.itc3_app_navigationmenu;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import android.view.View;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.google.android.material.navigation.NavigationView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {  //액션바 만드는애
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //툴바호출
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
//        팹버튼 호출
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "팹버튼으로 필터불러옵시다", Snackbar.LENGTH_LONG) //그냥 메시지띄워주는 액션
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);  //좌측에서 끌어와서 쓰는 레이아웃(네비게이션뷰)이 서랍처럼 열리게
        NavigationView navigationView = findViewById(R.id.nav_view);
        mAppBarConfiguration = new AppBarConfiguration.Builder(  //좌측에서 끌어오는 레이아웃(네비게이션뷰) 안에 들어가는 목록
                R.id.nav_home,  R.id.nav_slideshow,
                R.id.nav_tools, R.id.nav_share, R.id.nav_send)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
            //네비게이션뷰 선언. (네비게이션뷰==앱좌측메뉴)
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        //    액션바관련
        //액션바 설정하기//
        //액션바 타이틀 변경하기 (넣고싶은 이름 넣으면 됨)
        getSupportActionBar().setTitle("");
        //액션바 배경색 변경 (코드 넣으면 됨 색 미정)
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable());
        //홈버튼 표시
        //getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        //액션바 숨기기
        //hideActionBar();

        //액션버튼을 클릭했을때의 동작 아직 미추가
    }

    @Override
    public boolean onSupportNavigateUp() { //액션바상의 뒤로가기 버튼
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
    @Override
    public void onBackPressed(){  //스마트폰상의 뒤로가기버튼 누르면 좌측메뉴바 닫히게
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer((GravityCompat.START));
        } else {
            super.onBackPressed();
        }
    }
}